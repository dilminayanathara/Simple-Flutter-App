import 'package:flutter/material.dart';
import 'welcomepage.dart';
import 'package:firebase_core/firebase_core.dart';

void main () async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(

      options: const FirebaseOptions(
        apiKey: 'AIzaSyAB1nGPz0bNyQEeZNRbHqaOeXVfRY_l2-g',
        appId: '1:16427072623:android:6e7ab930b714bafc75219a',
        messagingSenderId: '',
        projectId: 'coffeeshop-21508',
      )
  );

    runApp(const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: firstpage(),
    ));
  }

