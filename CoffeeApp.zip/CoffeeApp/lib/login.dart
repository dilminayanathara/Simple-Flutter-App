import 'package:flutter/material.dart';
import 'home.dart';
import 'Register.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  final TextEditingController emailcon = TextEditingController();
  final TextEditingController passwordcon = TextEditingController();

  final FirebaseAuth _auth =FirebaseAuth.instance;

  Future<void> validate() async {

    String emailtext = emailcon.text;
    String passwordtext = passwordcon.text;

    if(emailtext.isEmpty || passwordtext.isEmpty) {

      showSnackBar(context, "Reqiured all fields");
    }else{

     try{

       final UserCredential users = await _auth.signInWithEmailAndPassword(
           email: emailtext,
           password: passwordtext,
       );

       if(users != null){
         Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeScreen()));
       }

     }catch(e){
       print(e);

       showSnackBar(context, "Login Unsuccessful");
    }

    }
    }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background container with image and gradient
          Container(
            decoration: BoxDecoration(
              color: Colors.black,
              image: DecorationImage(
                image: const AssetImage("images/login.jpg"),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                  Colors.black.withOpacity(0.9),
                  BlendMode.dstOver,
                ),
              ),
            ),
          ),
          // Arrow icon in the top-left corner
          Positioned(
            top: 40, // Adjust based on your UI padding needs
            left: 20, // Adjust based on your UI padding needs
            child: InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => HomeScreen())); // Navigate back
              },
              child: const Icon(
                Icons.arrow_back_ios_new,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),
          // Main content of the login page
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo
                Container(
                  height: 200,
                  width: 200,
                  child: Image.asset(
                    "images/logo.png",
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 20),
                // Email TextField
                TextField(
                  controller: emailcon,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    hintText: "Email",
                    hintStyle: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                SizedBox(height: 20),
                // Password TextField
                TextField(
                  controller: passwordcon,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    hintText: "Password",
                    hintStyle: const TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  style: const TextStyle(color: Colors.white, fontSize: 18),
                  obscureText: true,
                ),
                SizedBox(height: 10),
                const Text(
                  "Forget password?",
                  style: TextStyle(color: Color(0xffcdc2c2), fontSize: 15),
                ),
                const SizedBox(height: 20),
                // Login Button
                InkWell(
                  onTap: () {
                    validate();
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 60),
                    decoration: BoxDecoration(
                      color: Color(0xffe57734),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      "Login",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                const Text(
                  "or Signup using",
                  style: TextStyle(color: Colors.white, fontSize: 15),
                ),
                SizedBox(height: 10),
                // Social Icons
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>RegisterPage()));
                      },
                      child: const Icon(Icons.email, color: Colors.red, size: 40),
                    ),
                    const SizedBox(width: 30),
                    InkWell(
                      onTap: () {
                        
                      },
                      child: const Icon(Icons.facebook, color: Colors.blue, size: 40),
                    ),
                  ],
                ),




              ],
            ),
          ),
        ],
      ),
    );
  }
}


void showSnackBar(context ,String message){
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
        content: Text(message),
        duration: Duration(seconds: 3),
    )
  );
}