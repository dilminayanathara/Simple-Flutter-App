import 'package:flutter/material.dart';
import 'package:newpro/login.dart';
import 'home.dart';
import 'login.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override
  _RegisterPageState createState() => _RegisterPageState();
}
class _RegisterPageState extends State<RegisterPage> {


  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _comPassController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  void _saveData() async {
    String emailtext = _emailController.text;
    String password1text = _passwordController.text;
    String password2text = _comPassController.text;

    if (emailtext.isEmpty || password1text.isEmpty || password2text.isEmpty) {
      showSnackbar(context, "All fields are required");
    } else if (password1text != password2text) {
      showSnackbar(context, "passwords are not match");
    } else {
      await _firestore.collection("users").add({
        'email': emailtext,
        'password': password1text,
      });
      final UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: emailtext,
          password: password1text,
      );

      showSnackbar(context, "Successfully Registered");
      _emailController.clear();
      _passwordController.clear();
      _comPassController.clear();
      Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));


    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background container with image and gradient
          Container(
            decoration: BoxDecoration(
              color: Colors.black,
              image: DecorationImage(
                image: AssetImage("images/login.jpg"),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                  Colors.black.withOpacity(0.9),
                  BlendMode.dstOver,
                ),
              ),
            ),
          ),
          // Arrow icon in the top-left corner
          Positioned(
            top: 40, // Adjust based on your UI padding needs
            left: 20, // Adjust based on your UI padding needs
            child: InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => HomeScreen())); // Navigate back
              },
              child: const Icon(
                Icons.arrow_back_ios_new,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),
          // Main content of the login page
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo
                Container(
                  height: 200,
                  width: 200,
                  child: Image.asset(
                    "images/logo.png",
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 20),
                // Email TextField
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    hintText: "Email",
                    hintStyle: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                SizedBox(height: 20),
                // Password TextField
                TextField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    hintText: "Password",
                    hintStyle: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  style: TextStyle(color: Colors.white, fontSize: 18),
                  obscureText: true,
                ),
                SizedBox(height: 20),
                // Password TextField
                TextField(
                  controller: _comPassController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Colors.white),
                    ),
                    hintText: "Conform Password",
                    hintStyle:
                    const TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  style: const TextStyle(color: Colors.white, fontSize: 18),
                  obscureText: true,
                ),

                const SizedBox(height: 20),
                // Login Button
                InkWell(
                  onTap: () {
                    _saveData();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 60),
                    decoration: BoxDecoration(
                      color: const Color(0xffe57734),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      "Register",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "or Signup using",
                  style: TextStyle(color: Colors.white, fontSize: 15),
                ),
                const SizedBox(height: 10),
                // Social Icons
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {},
                      child:
                      const Icon(Icons.email, color: Colors.red, size: 40),
                    ),
                    const SizedBox(width: 30),
                    InkWell(
                      onTap: () {},
                      child: const Icon(Icons.facebook,
                          color: Colors.blue, size: 40),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void showSnackbar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 5),

      ),
    );
  }
}
